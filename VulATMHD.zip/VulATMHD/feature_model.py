import torch.nn as nn
import torch
from sup_contrastive_loss import TripletLossHardMining
# from sup_contrastive_loss import SupConLoss

class CNNTeacherModel(nn.Module):  
    def __init__(self, shared_model, tokenizer, num_labels, args, hidden_size):
        super().__init__()
        self.shared_model = shared_model
        self.category_head = nn.Linear(hidden_size, num_labels)
        self.class_head = nn.Linear(hidden_size, num_labels)
        self.variant_head = nn.Linear(hidden_size, num_labels)
        self.base_head = nn.Linear(hidden_size, num_labels)
        self.deprecated_head = nn.Linear(hidden_size, num_labels)
        # Note. pillar has only one label, so no need to train a head
        self.tokenizer = tokenizer
        self.args = args

        self.triplet_loss_fn = TripletLossHardMining(
            margin=0.6, 
            distance_metric='cosine'         # 或 'euclidean'
        )

        # self.supcon_loss_fn = SupConLoss(temperature=0.07)

    def forward(self, input_ids, groups, labels, return_prob=False, return_logit=False):
        # size: batch_size, num_labels
        hidden_state = self.shared_model(input_ids=input_ids, return_hidden_state=True)
        category_logits = self.category_head(hidden_state)
        class_logits = self.class_head(hidden_state)
        variant_logits = self.variant_head(hidden_state)
        base_logits = self.base_head(hidden_state)
        deprecated_logits = self.deprecated_head(hidden_state)
        # iter batch
        logits = torch.empty(category_logits.shape[0], category_logits.shape[1]).float().to(self.args.device)
        for i in range(len(groups)):
            if groups[i].item() == 0:
                logits[i, :] = category_logits[i]
            elif groups[i].item() == 1:
                logits[i, :] = class_logits[i]
            elif groups[i].item() == 2:
                logits[i, :] = variant_logits[i]
            elif groups[i].item() == 3:
                logits[i, :] = base_logits[i]
            elif groups[i].item() == 4:
                logits[i, :] = deprecated_logits[i]
            elif groups[i].item() == 5:
                logits[i, :] = labels[i]   
        if return_prob:
            prob = torch.softmax(logits, dim=-1)
            return prob
        elif return_logit:
            return logits, hidden_state
        else:
            loss_fct = nn.CrossEntropyLoss()
            loss = loss_fct(logits, labels)
            

            loss_triplet = self.triplet_loss_fn(hidden_state, self.args.device, labels) # 使用 ce_labels
            total_loss = loss + 0.07 * loss_triplet
            
            return total_loss
