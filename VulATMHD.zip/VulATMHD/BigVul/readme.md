The data folder contain csv files to reproduce most of the methods, we introduce x specific columns that are used in our experiments:
1. "func_before": original vulnerable functions
2. "CWE ID": CWE-ID labels
3. "cwe_abstract_group": CWE abstract types 

The data was originally collected from [Big-Vul Dataset](https://github.com/ZeoVan/MSR_20_Code_vulnerability_CSV_Dataset).